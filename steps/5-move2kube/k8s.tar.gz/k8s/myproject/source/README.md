# Containerize the App

The first step to deploying any app to platforms like Kubernetes and Openshift is to containerize the app.
We use Docker for building and pushing container images here but you could also use Podman, Buildah, etc.

## Steps

Build the image using the Dockerfile and push it to a container registry like Docker Hub or Quay.
```
$ docker build -t quay.io/my-username/my-web-app:v1 .
$ docker push quay.io/my-username/my-web-app:v1
```
